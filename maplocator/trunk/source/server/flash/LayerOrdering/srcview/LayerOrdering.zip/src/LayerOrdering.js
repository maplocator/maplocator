function toggleLayer(id, lbl, chk) {
	var obj = new Object();
	obj.id = id;
	obj.label = lbl;
	var flexRoot = FABridge.FAB_LayerOrdering.root();
	if(chk) {
		flexRoot.addItemAt(0, obj);
	} else {
		flexRoot.removeItem(obj);
	}
}

function reorderLayer(layer_tablename, cur_pos, new_pos) {
	alert(layer_tablename + " moved from " + cur_pos + " to " + new_pos);
}