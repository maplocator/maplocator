function getUrlParam(name, afterHash)
{
  if (afterHash == null) {
  	afterHash = false;
  }
  name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var queryString = window.location.href;
  var regexS = "[\\?&]"+name+"=([^&#]*)";
  if (afterHash) {
  	var indx = queryString.indexOf("#");
  	queryString = queryString.substring(indx);
  	regexS = "[\\#&]"+name+"=([^&]*)";
  }
  var regex = new RegExp( regexS );
  var results = regex.exec( queryString );
  if( results == null )
    return "";
  else
    return results[1];
}
